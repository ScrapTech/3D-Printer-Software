import re


class GCode2SCRPTCH():
    def __init__(self):
        self.replacements = [
            [r'Marlin', 'ScrapTechGRBL'],
            [r'G92(?:...)', ''],
            [r'(G(?:0|1|2|3).*)(?:X)([-\+]?[\d\.].*)(?:E)([-\+]?[\d\.].*)', r'\1X\2M3'],
            [r'(G(?:0|1|2|3).*)(?:E)([-\+]?[\d\.].*)', ''],
            [r'(G)(?:0)(.*F[0-9]+.*)', r'\g<1>1\g<2> M5'],
            [r'G10', ''],
            [r'M104(?:.....)', ''],
            [r'M105', ''],
            [r'M106(?:.....)', ''],
            [r'M107', ''],
            [r'M109(?:.....)', ''],
            [r'M104(?:...)', ''],
            [r'M82(?:.........................)', '']
        ]

        self.endCode = 'M2 ; end of program'
        self.endTerm = r'(?:\s*M2.*|\s%.*)'

        self.regMatch = []
        self.endRegex = None

        self.hasProgramEnd = False

    def compile_regex(self):
        for self.regexString, self.replacement in self.replacements:
            regex = re.compile(self.regexString, flags=re.IGNORECASE)
            self.regMatch.append([regex, self.replacement])
        self.endRegex = re.compile(self.endTerm, flags=re.IGNORECASE)

    def do_regex_replacements(self, line):
        for regex, replacement in self.regMatch:
            line = regex.sub(replacement, line)
        return line

    def prepare_processing(self):
        self.hasProgramEnd = False
        self.compile_regex()

    def process_layer(self, data):
        data = self.do_regex_replacements(data)
        if (not self.hasProgramEnd) and self.endRegex.match(data):  # check for end of program
            self.hasProgramEnd = True
        return data

    def finalize_processing(self, data):
        if not self.hasProgramEnd:
            data += self.endCode + '\n'
        return data

    def process(self, data):
        self.prepare_processing()

        data = self.process_layer(data)

        data = self.finalize_processing(data)

        return data
