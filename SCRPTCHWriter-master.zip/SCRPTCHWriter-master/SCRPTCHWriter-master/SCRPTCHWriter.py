# Copyright (c) 2020 ScrapTech
# SCRPTCHWriter is released under the terms of the AGPLv3 or higher.
import io  # For StringIO to write the g-code to a buffer.
import os
import sys

from UM.Mesh.MeshWriter import MeshWriter
from UM.Logger import Logger
from UM.PluginRegistry import PluginRegistry

from UM.i18n import i18nCatalog

path = os.path.dirname(os.path.realpath(__file__))
if path not in sys.path:
    sys.path.append(path)
from converter.gcode2SCRPTCH import GCode2SCRPTCH
from converter.SCRPTCH2ve import SCRPTCH2Ve

catalog = i18nCatalog("cura")


class SCRPTCHWriter(MeshWriter):
    version = 3

    def __init__(self):
        super().__init__()

    def write(self, stream, nodes, mode=MeshWriter.OutputMode.TextMode):
        if mode != MeshWriter.OutputMode.TextMode:
            Logger.log("e", "SCRPTCH Writer does not support non-text mode.")
            self.setInformation(catalog.i18nc("@error:not supported", "SCRPTCHWriter does not support non-text mode."))
            return False

        # Get the g-code.
        gcode = io.StringIO()
        PluginRegistry.getInstance().getPluginObject("GCodeWriter").write(gcode, None)
        gcode = gcode.getvalue()

        gcodeConverter = GCode2SCRPTCH()
        veConverter = SCRPTCH2Ve()
        gcode = gcodeConverter.process(gcode)

        stream.write(gcode)

        return True
