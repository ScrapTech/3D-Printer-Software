# Copyright (c) 2015 Ultimaker B.V.
# Cura is released under the terms of the AGPLv3 or higher.

from . import SCRPTCHWriter

from UM.i18n import i18nCatalog
catalog = i18nCatalog("cura")


def getMetaData():
    return {
        "mesh_writer": {
            "output": [{
                "extension": "SCRPTCH",
                "description": catalog.i18nc("@item:inlistbox", "ScrapTech GCode File"),
                "mime_type": "text/x-SCRPTCH",
                "mode": SCRPTCHWriter.SCRPTCHWriter.OutputMode.TextMode
            }]
        }
    }


def register(app):
    return { "mesh_writer": SCRPTCHWriter.SCRPTCHWriter() }
